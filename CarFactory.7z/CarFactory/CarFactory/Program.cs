﻿using CarFactory;

class Program
{
    
        static void Main()
        {
            ICarFactory sedanFactory = new SedanFactory();
            ICarFactory suvFactory = new SUVFactory();

            ICar sedan = sedanFactory.CreateCar();
            ICar suv = suvFactory.CreateCar();

            sedan.Accelerate();
            suv.Accelerate();
        suv.Accelerate();
        suv.DisplayInfo();
        }
}